<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Wybór tematów projektowych') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">

                    <div class="card">
               
                        <div class="card-header">{{ __('Wysyłanie projektu') }}</div>
        
                        <div class="card-body">
                       
                            <h3 class="text-center mb-3">Upload Center</h3>
                            <p>
                            Wyślij swój projekt pt. <b>"{{$topic->title}}"</b> w archiwum (.zip, .rar, .7z, .tar) o maksymalnej wielkości 100 MB. <br/>
                            Dozwolone jest 3-krotne wysłanie archiwów w ramach poprawy oceny. <br/>
        
                            <h5 style="color:red">Jeśli wyślesz swoje pierwsze archiwum zmiana tematu nie będzie możliwa!</h5>
                           </p>      
                       
                            <b>Twoje przesłane pliki ({{Auth::user()->files->count()}}/3 możliwych prób):</b>
                            <ul>
                                @foreach ($files as $file)
                                     <li class="small text-muted"><a href="{{asset($file->file_path)}}"> {{$file->name}} </a></li>
                                @endforeach  
                            </ul>
                            <form action="{{route('fileUpload')}}" method="post" enctype="multipart/form-data">
        
                                  @csrf
                                  @if ($message = Session::get('success'))
                                  <div class="alert alert-success">
                                      <strong>{{ $message }}</strong>
                                  </div>
                                @endif
                      
                                @if (count($errors) > 0)
                                  <div class="alert alert-danger">
                                      <ul>
                                          @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                          @endforeach
                                      </ul>
                                  </div>
                                @endif
        
                                  <div class="custom-file">
                                      <input type="file" name="file" class="custom-file-input" id="chooseFile">
                                      <label class="custom-file-label" for="chooseFile">Wybierz plik</label>
                                  </div>
                                  <div class="btnsShow">
                                  <input type="hidden" name="user_id" value="{{Auth::user()->id}}"/>
        
                                <button class="btn btn-primary mt-3"><a href="{{route("topicMyProject")}}">Powrót</a></button>
        
                                @if(Auth::user()->files->count() != 3)
                                  <button class="btn btn-success mt-3" type="submit" name="submit" class="btn btn-primary mt-3">
                                      Wyślij projekt
                                  </button>
                                @else
                                     <button class="btn btn-success mt-3" disabled>3/3 wykorzystane próby</button>    
                                @endif
        
                                </div>
                              </form>
        
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
    </div>
</x-app-layout>